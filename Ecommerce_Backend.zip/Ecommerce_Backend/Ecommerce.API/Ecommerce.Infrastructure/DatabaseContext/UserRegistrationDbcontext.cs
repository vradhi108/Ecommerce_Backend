﻿using System;
using Microsoft.EntityFrameworkCore;
using Ecommerce.Shared.Models;
namespace Ecommerce.Infrastructure.DatabaseContext
{
    public partial class UserRegistrationDbcontext: DbContext
    {
        public UserRegistrationDbcontext(DbContextOptions<UserRegistrationDbcontext> options):
            base(options){ }

        public virtual DbSet<UserRegistration> Ecommerce_User_Registration { get; set; }
        public virtual DbSet<Admin> AdminCredentilsTable { get; set; }

        public virtual DbSet<SellerRegistration> SellerRegistrationsVB { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserRegistration>(entity => {
                entity.HasKey(k => k.Id);
            });
            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
